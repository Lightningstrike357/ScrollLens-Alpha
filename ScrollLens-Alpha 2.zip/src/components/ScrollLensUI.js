import { useState } from 'react';

export default function ScrollLensUI() {
  const [thoughts, setThoughts] = useState("");
  const [glyphs, setGlyphs] = useState([]);

  const handleGenerateThought = () => {
    setThoughts("Suggested build: Fusion Protocol – Alpha Node");
  };

  const handleGenerateGlyph = () => {
    setGlyphs(["◆", "⚡", "♜"]);
  };

  return (
    <div className="grid grid-cols-2 grid-rows-2 gap-4 p-6 bg-black text-white min-h-screen">
      <div className="col-span-1 row-span-2 bg-gray-900 p-4 rounded">
        <h2 className="text-xl font-bold mb-4">ScrollLens Interface</h2>
        <div className="grid grid-cols-2 gap-2">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="p-2 border border-white rounded">Scroll {i + 1}</div>
          ))}
        </div>
        <div className="flex gap-2 mt-4">
          <input placeholder="Search..." className="bg-gray-800 p-2 flex-1 rounded" />
          <button className="bg-white text-black px-4 py-2 rounded">🔍</button>
        </div>
      </div>

      <div className="bg-gray-900 p-4 rounded">
        <h2 className="text-xl font-bold mb-4">Autonomous Thought Layer</h2>
        <div className="mb-2">{thoughts}</div>
        <button onClick={handleGenerateThought} className="bg-white text-black px-4 py-2 rounded">Generate</button>
      </div>

      <div className="bg-gray-900 p-4 rounded">
        <h2 className="text-xl font-bold mb-4">Codex Builder</h2>
        <div className="text-sm">
          ▷ Root Scroll<br />
          ├─ Wisdom Node A<br />
          ├─ Wisdom Node B<br />
          └─ Node C
        </div>
      </div>

      <div className="bg-gray-900 p-4 rounded">
        <h2 className="text-xl font-bold mb-4">Silent Assist</h2>
        <div className="text-sm">Live backchannel ready. Listening for field speech...</div>
      </div>

      <div className="bg-gray-900 p-4 rounded">
        <h2 className="text-xl font-bold mb-4">Glyph Output Generator</h2>
        <div className="flex gap-4 text-2xl mb-2">{glyphs.map((g, i) => <span key={i}>{g}</span>)}</div>
        <button onClick={handleGenerateGlyph} className="bg-white text-black px-4 py-2 rounded">Generate</button>
      </div>
    </div>
  );
}