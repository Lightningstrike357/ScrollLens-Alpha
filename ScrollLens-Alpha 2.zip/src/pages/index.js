import ScrollLensUI from '../components/ScrollLensUI';

export default function Home() {
  return <ScrollLensUI />;
}